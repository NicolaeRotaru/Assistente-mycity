# MyCity Assistant — Fase 1

Il tuo assistente AI personale per gestire MyCity.
Dashboard + chat AI collegata a Supabase e Stripe.

## Cosa fa adesso
- Chat AI in italiano (modello Claude Sonnet)
- Legge ordini e notifiche da Supabase
- Legge incassi e pagamenti da Stripe (demo)
- Dashboard con metriche e notifiche

## Come avviarlo (3 passi)

### 1. Installa le librerie
Apri il terminale nella cartella del progetto e scrivi:
    npm install

### 2. Inserisci le tue chiavi
- Copia il file `.env.example` e rinominalo in `.env.local`
- Riempi le 4 chiavi (le hai gia tutte: Anthropic, Supabase, Stripe)

### 3. Avvia
    npm run dev
Apri il browser su: http://localhost:3000

## Note importanti
- Le tabelle Supabase usate sono: `orders`, `notifications`.
  Se i tuoi nomi sono diversi, cambiali in `src/lib/runTool.ts`.
- Stripe e in modalita test: i numeri sono finti finche non vai live.
- Le chiavi nel file `.env.local` restano solo sul tuo PC.

## Come aggiungere nuove capacita
Ogni "azione" che l'AI puo fare vive in 2 file:
1. `src/lib/tools.ts` — descrivi cosa fa lo strumento
2. `src/lib/runTool.ts` — scrivi cosa fa davvero
Cosi in futuro aggiungi GitHub, Gmail, WhatsApp, ecc.

## Mettere online (quando sei pronto)
Carica su GitHub, poi collega a Vercel (gratis).
Inserisci le stesse chiavi nelle impostazioni di Vercel.
