import { createClient } from "@supabase/supabase-js";

// Connessione al database MyCity.
// Usa la service role key: legge tutti i dati lato server, mai esposta al browser.
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { persistSession: false } }
);
