import Anthropic from "@anthropic-ai/sdk";

// Gli "strumenti" sono le azioni che l'assistente puo compiere.
// L'AI legge la descrizione e decide da sola quale usare in base alla richiesta.
// Aggiungere una nuova capacita = aggiungere uno strumento qui.

export const tools: Anthropic.Tool[] = [
  {
    name: "leggi_ordini",
    description:
      "Legge gli ordini recenti dal database MyCity. Usalo quando l'utente chiede di ordini, vendite, consegne, o quanti ordini ci sono stati.",
    input_schema: {
      type: "object",
      properties: {
        limite: {
          type: "number",
          description: "Quanti ordini leggere (default 10)",
        },
        stato: {
          type: "string",
          description:
            "Filtra per stato, es. 'in_consegna', 'consegnato', 'problema'. Opzionale.",
        },
      },
    },
  },
  {
    name: "leggi_notifiche",
    description:
      "Legge le notifiche della piattaforma: problemi rider, ordini bloccati, segnalazioni. Usalo quando l'utente chiede 'cosa e successo', 'ci sono problemi', o cita una notifica.",
    input_schema: {
      type: "object",
      properties: {
        solo_non_lette: {
          type: "boolean",
          description: "Se true mostra solo le notifiche non lette",
        },
      },
    },
  },
  {
    name: "conta_incassi_stripe",
    description:
      "Legge gli incassi e i pagamenti da Stripe (modalita demo). Usalo per domande su soldi, fatturato, pagamenti falliti, rimborsi.",
    input_schema: {
      type: "object",
      properties: {
        giorni: {
          type: "number",
          description: "Quanti giorni indietro guardare (default 7)",
        },
      },
    },
  },
];

export type ToolName = "leggi_ordini" | "leggi_notifiche" | "conta_incassi_stripe";
