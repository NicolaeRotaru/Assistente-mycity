import Stripe from "stripe";

// Connessione a Stripe in modalita test/demo.
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
});
