import { supabase } from "./supabase";
import { stripe } from "./stripe";
import type { ToolName } from "./tools";

// Qui vivono le azioni REALI. Quando l'AI sceglie uno strumento,
// viene eseguita la funzione corrispondente e il risultato torna all'AI.

export async function runTool(name: ToolName, input: any): Promise<string> {
  try {
    switch (name) {
      case "leggi_ordini": {
        const limite = input.limite ?? 10;
        let query = supabase
          .from("orders")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(limite);
        if (input.stato) query = query.eq("status", input.stato);
        const { data, error } = await query;
        if (error) return `Errore lettura ordini: ${error.message}`;
        return JSON.stringify(data ?? []);
      }

      case "leggi_notifiche": {
        let query = supabase
          .from("notifications")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(20);
        if (input.solo_non_lette) query = query.eq("read", false);
        const { data, error } = await query;
        if (error) return `Errore lettura notifiche: ${error.message}`;
        return JSON.stringify(data ?? []);
      }

      case "conta_incassi_stripe": {
        const giorni = input.giorni ?? 7;
        const da = Math.floor(Date.now() / 1000) - giorni * 86400;
        const charges = await stripe.charges.list({
          created: { gte: da },
          limit: 100,
        });
        const totale = charges.data
          .filter((c) => c.paid)
          .reduce((s, c) => s + c.amount, 0);
        const falliti = charges.data.filter((c) => !c.paid).length;
        return JSON.stringify({
          incasso_totale_euro: (totale / 100).toFixed(2),
          numero_pagamenti: charges.data.length,
          pagamenti_falliti: falliti,
          periodo_giorni: giorni,
        });
      }

      default:
        return "Strumento sconosciuto.";
    }
  } catch (e: any) {
    return `Errore durante l'esecuzione: ${e.message}`;
  }
}
