import Anthropic from "@anthropic-ai/sdk";
import { tools, type ToolName } from "@/lib/tools";
import { runTool } from "@/lib/runTool";
import { NextRequest, NextResponse } from "next/server";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

const SYSTEM = `Sei l'assistente personale di MyCity, il marketplace dei negozi di Piacenza.
Parli sempre in italiano, in modo chiaro e diretto.
Hai accesso a strumenti per leggere ordini, notifiche e incassi.
Quando l'utente ti chiede qualcosa, usa lo strumento giusto e poi spiega il risultato in modo semplice.
Prima di compiere azioni che modificano dati (rimborsi, invii), descrivi cosa stai per fare.`;

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();
    const conversation: Anthropic.MessageParam[] = [...messages];

    // Ciclo: l'AI puo chiedere di usare uno strumento, noi lo eseguiamo e glielo ridiamo.
    for (let i = 0; i < 5; i++) {
      const res = await anthropic.messages.create({
        model: "claude-sonnet-4-6",
        max_tokens: 1500,
        system: SYSTEM,
        tools,
        messages: conversation,
      });

      const toolUses = res.content.filter((b) => b.type === "tool_use");

      if (toolUses.length === 0) {
        const text = res.content
          .filter((b): b is Anthropic.TextBlock => b.type === "text")
          .map((b) => b.text)
          .join("\n");
        return NextResponse.json({ reply: text });
      }

      conversation.push({ role: "assistant", content: res.content });
      const results: Anthropic.ToolResultBlockParam[] = [];
      for (const tu of toolUses) {
        const out = await runTool(tu.name as ToolName, tu.input);
        results.push({ type: "tool_result", tool_use_id: tu.id, content: out });
      }
      conversation.push({ role: "user", content: results });
    }

    return NextResponse.json({ reply: "Troppi passaggi, riprova con una richiesta piu semplice." });
  } catch (e: any) {
    return NextResponse.json({ reply: `Errore: ${e.message}` }, { status: 500 });
  }
}
